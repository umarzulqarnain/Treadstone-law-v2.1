/******/ (() => { // webpackBootstrap
/*!******************************************!*\
  !*** ../demo3/src/js/pages/my-script.js ***!
  \******************************************/
/*! unknown exports (runtime-defined) */
/*! runtime requirements:  */

/******/ })()
;