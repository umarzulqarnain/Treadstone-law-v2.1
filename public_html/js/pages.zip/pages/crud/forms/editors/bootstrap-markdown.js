/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!**********************************************************************!*\
  !*** ../demo3/src/js/pages/crud/forms/editors/bootstrap-markdown.js ***!
  \**********************************************************************/
/*! unknown exports (runtime-defined) */
/*! runtime requirements:  */

// Class definition

var KTBootstrapMarkdown = function () {    
    // Private functions
    var demos = function () {
        
    }

    return {
        // public functions
        init: function() {
            demos(); 
        }
    };
}();

// Initialization
jQuery(document).ready(function() {
    KTBootstrapMarkdown.init();
});
/******/ })()
;
//# sourceMappingURL=bootstrap-markdown.js.map