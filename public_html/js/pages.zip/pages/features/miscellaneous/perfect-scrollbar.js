/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!*************************************************************************!*\
  !*** ../demo3/src/js/pages/features/miscellaneous/perfect-scrollbar.js ***!
  \*************************************************************************/
/*! unknown exports (runtime-defined) */
/*! runtime requirements:  */


// Class definition
var KTScrollable = function () {
    
    // Private functions

    // basic demo
    var demo1 = function () {
    }

    return {
        // public functions
        init: function() {
            demo1();
        }
    };
}();

jQuery(document).ready(function() {    
    KTScrollable.init();
});
/******/ })()
;
//# sourceMappingURL=perfect-scrollbar.js.map